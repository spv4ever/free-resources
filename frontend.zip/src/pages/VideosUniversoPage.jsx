import React from 'react';
import NasaMediaGallery from './NasaMediaGallery';

function VideosUniversoPage() {
  return <NasaMediaGallery mediaType="video" />;
}

export default VideosUniversoPage;
