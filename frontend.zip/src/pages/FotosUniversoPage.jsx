import React from 'react';
import NasaMediaGallery from './NasaMediaGallery';

function FotosUniversoPage() {
  return <NasaMediaGallery mediaType="image" />;
}

export default FotosUniversoPage;
